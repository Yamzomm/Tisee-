const shell =
  document.getElementById("searchShell");

const panel =
  document.getElementById("searchPanel");

const searchBar =
  document.getElementById("searchBar");

const searchButton =
  document.getElementById("searchButton");

const verticalTrack =
  document.getElementById("verticalTrack");

const searchInput =
  document.getElementById("searchInput");

const resultTitle =
  document.getElementById("resultTitle");

const resultDescription =
  document.getElementById("resultDescription");

const resultCards =
  document.getElementById("resultCards");


/* =========================================================
   DEMO DATA
   Replace this with real backend/API data later.
   ========================================================= */

const data = {

  host: {

    lhasa: [
      {
        name: "Lhamu",
        meta: "八廓街 · Local market & everyday culture"
      },
      {
        name: "Tsering",
        meta: "老城故事 · 藏餐与社区散步"
      }
    ],

    shigatse: [
      {
        name: "Sonam",
        meta: "老城文化 · 市场与寺院周边生活"
      }
    ],

    chamdo: [
      {
        name: "Kelsang",
        meta: "昌都老城 · 日常文化路线"
      }
    ],

    nyingchi: [
      {
        name: "Yangchen",
        meta: "村落与自然 · 本地生活体验"
      }
    ],

    shannan: [
      {
        name: "Tashi",
        meta: "山南文化 · 村落与历史路线"
      }
    ],

    nagqu: [
      {
        name: "Namgyal",
        meta: "草原生活 · 牧区文化体验"
      }
    ],

    ngari: [
      {
        name: "Lobsang",
        meta: "阿里文化 · 山地路线与地方故事"
      }
    ]

  },


  stay: {

    lhasa: [
      {
        name: "Barkhor Family Stay",
        meta: "八廓街附近 · 本地家庭经营"
      }
    ],

    shigatse: [
      {
        name: "Shigatse Family House",
        meta: "老城附近 · 家庭式住宿"
      }
    ],

    chamdo: [
      {
        name: "Chamdo Riverside Stay",
        meta: "昌都市区 · 本地家庭接待"
      }
    ],

    nyingchi: [
      {
        name: "Nyingchi Village Home",
        meta: "村落景观 · 家庭餐食"
      }
    ],

    shannan: [
      {
        name: "Shannan Courtyard Stay",
        meta: "传统院落 · 家庭式住宿"
      }
    ],

    nagqu: [
      {
        name: "Nagqu Family Guesthouse",
        meta: "牧区文化体验 · 家庭接待"
      }
    ],

    ngari: [
      {
        name: "Ngari Local Lodge",
        meta: "小型本地住宿 · 文化路线方便"
      }
    ]

  }

};


const regionNames = {

  lhasa: "拉萨",

  shigatse: "日喀则",

  chamdo: "昌都",

  nyingchi: "林芝",

  shannan: "山南",

  nagqu: "那曲",

  ngari: "阿里"

};


let selectedType = "host";

let selectedRegion = "lhasa";


/* =========================================================
   IDLE REGION ANIMATION
   Each region stays ~1 second, then rolls upward.
   ========================================================= */

const itemHeight = 56;

const realItemCount = 7;

let currentIndex = 0;

let animationTimer = null;

let animationStopped = false;


function startRegionAnimation() {

  animationTimer =
    setInterval(() => {

      if (animationStopped) {
        return;
      }

      currentIndex += 1;

      verticalTrack.style.transition =
        "transform .3s cubic-bezier(.22,.61,.36,1)";

      verticalTrack.style.transform =
        `translateY(-${currentIndex * itemHeight}px)`;


      /*
       * When reaching duplicated first item,
       * reset instantly back to the real first item.
       */
      if (currentIndex === realItemCount) {

        setTimeout(() => {

          verticalTrack.style.transition =
            "none";

          currentIndex = 0;

          verticalTrack.style.transform =
            "translateY(0)";


          requestAnimationFrame(() => {

            verticalTrack.style.transition =
              "transform .3s cubic-bezier(.22,.61,.36,1)";

          });

        }, 320);

      }

    }, 1000);

}


function stopRegionAnimation() {

  animationStopped = true;

  if (animationTimer) {
    clearInterval(animationTimer);
  }

  shell.classList.add("active");

}


/* =========================================================
   OPEN SEARCH
   ========================================================= */

function openSearch() {

  stopRegionAnimation();

  panel.classList.add("open");

  panel.setAttribute(
    "aria-hidden",
    "false"
  );

}


searchBar.addEventListener(
  "click",
  openSearch
);


searchButton.addEventListener(
  "click",
  event => {

    event.stopPropagation();

    openSearch();

  }
);


/* =========================================================
   TYPE SWITCH
   ========================================================= */

document
  .querySelectorAll(".type-button")
  .forEach(button => {

    button.addEventListener(
      "click",
      () => {

        document
          .querySelectorAll(".type-button")
          .forEach(item => {

            item.classList.remove("active");

          });

        button.classList.add("active");

        selectedType =
          button.dataset.type;

        renderResults();

      }
    );

  });


/* =========================================================
   REGION SWITCH
   ========================================================= */

document
  .querySelectorAll(".region-button")
  .forEach(button => {

    button.addEventListener(
      "click",
      () => {

        document
          .querySelectorAll(".region-button")
          .forEach(item => {

            item.classList.remove("active");

          });

        button.classList.add("active");

        selectedRegion =
          button.dataset.region;

        renderResults();

      }
    );

  });


/* =========================================================
   RENDER RESULTS
   ========================================================= */

function renderResults() {

  const typeLabel =
    selectedType === "host"
      ? "Local Host"
      : "民宿";

  const regionLabel =
    regionNames[selectedRegion];

  searchInput.value =
    `${regionLabel} · ${typeLabel}`;

  resultTitle.textContent =
    `${regionLabel}的 ${typeLabel}`;

  resultDescription.textContent =
    `后续接入后端后，这里显示真实注册的 ${typeLabel}。`;

  const items =
    data[selectedType][selectedRegion] || [];


  resultCards.innerHTML =
    items
      .map(item => `

        <article class="result-card">

          <div class="result-name">
            ${item.name}
          </div>

          <div class="result-meta">
            ${item.meta}
          </div>

        </article>

      `)
      .join("");

}


/* =========================================================
   CLOSE WHEN CLICKING OUTSIDE
   ========================================================= */

document.addEventListener(
  "click",
  event => {

    if (!shell.contains(event.target)) {

      panel.classList.remove("open");

      panel.setAttribute(
        "aria-hidden",
        "true"
      );

    }

  }
);


/* =========================================================
   INIT
   ========================================================= */

renderResults();

startRegionAnimation();
